package pal;

import java.util.*;

public class NetworkGenerator {

    Node[] newGraph;
    int old_n_connections, old_n_servers;
    int[] set;
    PriorityQueue<Network> possibleNetworks = new PriorityQueue<>();
    Network oldNetwork;
//    int max_fast_servers;
//    List<Network> fastestNetworks = new ArrayList<>();

    public NetworkGenerator(Map<Integer,List<Node>> newGraphEdges, int[] set, Node[] newGraph, int old_n_connections, int old_n_servers, Network oldNetwork) {
        this.set = set;
        this.newGraph = newGraph;
        this.old_n_connections = old_n_connections;
        this.old_n_servers = old_n_servers;
        this.oldNetwork = oldNetwork;
    }

    public final boolean isConnected(Network network) {
        Deque<Node> queue = new ArrayDeque<>();
        Set<Integer> visited = new HashSet<>();
        queue.offerFirst(network.nodes.get(0));
        int edgeCount = 0;

        while (!queue.isEmpty()) {
            Node u = queue.removeLast();
            if (!visited.contains(u.id)) {
                if (u.isFast)
                    network.fast_servers++;
                visited.add(u.id);
//                System.out.print(u.id + ", ");
                for (Node v : u.adjacentNodes) {
                    if (!visited.contains(v.id) && network.nodes.contains(v)) {
                        edgeCount++;
                        queue.offerFirst(v);
                    }
                }
            }
        }

        return visited.size() == old_n_servers;
    }

    private final List<Integer> getAdjacentDegreesForNodeInNetwork(Node n, Network p) {
        List<Integer> adjacentDegrees = new ArrayList<>();

        for (Node adj : n.adjacentNodes) {
            if (p.nodes.contains(adj)) {
                int count = 0;
                for (Node i : adj.adjacentNodes){
                    if (p.nodes.contains(i))
                        count++;
                }
                adjacentDegrees.add(count);
            }
        }
        Collections.sort(adjacentDegrees);
        return adjacentDegrees;
    }

    private final int countDegreeForNodeInPack(Node n, Network p) {
        int count = 0;

        for (Node i : n.adjacentNodes) {
            if (p.nodes.contains(i))
                count++;
        }
        return count;
    }

    // update pack's node degrees array -> sorted
    // map to each node pack.id -> list adjacent node degrees
    final void  updateNetworkNodeDegrees(Network network) {
        int[] degreesArray = new int[network.nodes.size()];
        List<List<Node>> adjacentDegrees = new ArrayList<>();

//        for(int i =0; i < network.nodes.size(); i++ )
//            adjacentDegrees.add(new ArrayList<>());

        for(int i =0; i < network.nodes.size(); i++ ){
            Node current = network.nodes.get(i);
            degreesArray[i] = countDegreeForNodeInPack(current,network);
//            adjacentDegrees.get(degreesArray[i]).add(current);
//            current.adjacentDegreesMap.put(network, getAdjacentDegreesForNodeInNetwork(current, network));
        }

        Arrays.sort(degreesArray);
        network.sortedDegrees = degreesArray;
//        network.adjacentDegrees = adjacentDegrees;
    }

    public final void createNetwork(int[] subset) {
        Network network = new Network();

        for (int i : subset) {
            network.nodes.add(newGraph[i]);
        }
        
        if (!isConnected(network))
            return;

        updateNetworkNodeDegrees(network);

        if (!Arrays.equals(network.sortedDegrees, oldNetwork.sortedDegrees))
            return;

//        if (network.fast_servers > max_fast_servers) {
//            max_fast_servers = network.fast_servers;
//            fastestNetworks = new ArrayList<>();
//            fastestNetworks.add(network);
//        } else if (network.fast_servers == max_fast_servers) {
//            fastestNetworks.add(network);
//        }

//        System.out.println(Arrays.toString(subset) + "  ->" + network.fast_servers);
        possibleNetworks.add(network);
    }


    //       3. -------------------------------------------------------------------------
//       Idea:
//       Collect the items of the subset in a single result list.
//       Add one item to the result on each recursion level.
//       The technical advantage of the idea is that no
//       intermediate lists (results) are generated.
    public final void k_subsets(int k, int i_start, int[] result, int depth){
        if (depth == k){
            createNetwork(result);
            return;
        }

        int i_lastStart = set.length - (k-depth);
        for (int i = i_start; i < i_lastStart+1; i++) {
            result[depth] = set[i];
            k_subsets(k, i+1, result, depth+1);
        }
    }
}

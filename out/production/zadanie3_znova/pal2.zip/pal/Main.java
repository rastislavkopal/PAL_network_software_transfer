package pal;

import java.io.IOException;
import java.util.*;

public class Main {

    static int old_n_servers, old_n_connections, new_n_servers, new_n_connections, n_fast_servers;
    static Node[] oldGraph;
    static Node[] newGraph;
    static List<Integer> fastServers = new ArrayList<>();
    static Map<Integer, List<Node>> newGraphEdges = new HashMap<>();
    static NetworkGenerator generator;

    public static final void read() throws IOException {
        InputReader r = new InputReader();
        old_n_servers = r.nextInt();
        old_n_connections = r.nextInt();

        oldGraph = new Node[old_n_servers];
        for (int i = 0; i < old_n_servers; i++)
            oldGraph[i] = new Node(i);

        for (int i = 0; i < old_n_connections; i++) {
            int start = r.nextInt();
            int end = r.nextInt();
            oldGraph[start].adjacentNodes.add(oldGraph[end]);
            oldGraph[end].adjacentNodes.add(oldGraph[start]);
        }

        new_n_servers = r.nextInt();
        new_n_connections = r.nextInt();
        n_fast_servers  = r.nextInt();

        for (int i = 0; i < n_fast_servers; i++) {
            int fast = r.nextInt();
            fastServers.add(fast);
        }

        newGraph = new Node[new_n_servers];
        for (int i = 0; i < new_n_servers; i++) {
            newGraph[i] = new Node(i);
            if (fastServers.contains(i))
                newGraph[i].isFast = true;
            newGraphEdges.put(i, new ArrayList<>());
        }

        for (int i = 0; i < new_n_connections; i++) {
            int start = r.nextInt();
            int end = r.nextInt();
            int cost = r.nextInt();
            newGraph[start].adjacentNodes.add(newGraph[end]);
            newGraph[end].adjacentNodes.add(newGraph[start]);

            newGraphEdges.get(start).add(new Node(end, cost));
            newGraphEdges.get(end).add(new Node(start, cost));
        }

    }

    private static final boolean hasIntersection(Network p1, Network p2) {
        for (Node n : p1.nodes){
            for (Node x : p2.nodes){
                if (n.equals(x))
                    return true;
            }
        }
        return false;
    }

//    public static final boolean areIsomoprhic(Network p1, Network p2 ) {
//        if (!Arrays.equals(p1.sortedDegrees, p2.sortedDegrees))
//            return false;
//
//        Set<Integer> used = new HashSet<>();
//        // for each possible number of degrees : 0,1 ..
//        for (int i = 0; i < p1.nodes.size(); i++) {
//            // for each in current number of degrees
//           for (Node node : p1.adjacentDegrees.get(i)) {
//               // find in p2 node with same adjacent-node's-degrees
//               boolean found = false;
//               for (Node to : p2.adjacentDegrees.get(i)) {
//                   if (!used.contains(to.id) && node.adjacentDegreesMap.get(p1).equals(to.adjacentDegreesMap.get(p2))) {
//                       found = true;
//                       used.add(to.id);
//                       break;
//                   }
//               }
//               if (!found)
//                   return false;
//           }
//        }
//        return true;
//    }

    private static void printPacks(Network p1, Network p2){
        StringBuilder sb = new StringBuilder();
        for (Node n : p1.nodes) {
            sb.append(n.id).append(" ");
        }
        for (Node n : p2.nodes) {
            sb.append(n.id).append(" ");
        }

        System.out.println(sb.toString());
    }

    // for each pack compare to all other packs
//    public static final void runPackCombinations() {
//        Set<List<Integer>> outputs = new HashSet<>();
//        for (Network pack : generator.possibleNetworks) {
//            for (Network other : generator.possibleNetworks) {
//                if (pack.equals(other))
//                    continue;
//
//                if (areIsomoprhic(pack, other) && !hasIntersection(pack, other)){
//                    List<Integer> curr = new ArrayList<>();
//                    List<Integer> curr2 = new ArrayList<>();
//                    for (Node n : pack.nodes)
//                        curr.add(n.id);
//                    for (Node n : other.nodes)
//                        curr2.add(n.id);
//
//                    if (!outputs.contains(curr)) {
//                        printPacks(pack, other);
//                        outputs.add(curr2);
//                    }
//                }
//
//            }
//        }
//    }

    private static int countDegreeForNodeInNetwork(Node n, Network p) {
        int count = 0;

        for (Node i : n.adjacentNodes) {
            if (p.nodes.contains(i))
                count++;
        }
        return count;
    }

    private List<Integer> getAdjacentDegreesForNodeInOldNetwork(Node n) {
        List<Integer> adjacentDegrees = new ArrayList<>();

        for (Node adj : n.adjacentNodes) {
            if (oldNetwork.nodes.contains(adj)) {
                int count = 0;
                for (Node i : adj.adjacentNodes){
                    if (oldNetwork.nodes.contains(i))
                        count++;
                }
                adjacentDegrees.add(count);
            }
        }
        Collections.sort(adjacentDegrees);
        return adjacentDegrees;
    }

    // update pack's node degrees array -> sorted
    // map to each node pack.id -> list adjacent node degrees
    static void updateNetworkNodeDegrees(Network network) {
        int[] degreesArray = new int[network.nodes.size()];
//        List<List<Node>> adjacentDegrees = new ArrayList<>();

//        for(int i =0; i < network.nodes.size(); i++ )
//            adjacentDegrees.add(new ArrayList<>());

        for(int i =0; i < network.nodes.size(); i++ ){
            Node current = network.nodes.get(i);
            degreesArray[i] = countDegreeForNodeInNetwork(current,network);
//            adjacentDegrees.get(degreesArray[i]).add(current);
//            current.adjacentDegreesMap.put(network, getAdjacentDegreesForNodeInOldNetwork(current, pack));
        }

        Arrays.sort(degreesArray);
        network.sortedDegrees = degreesArray;
//        network.adjacentDegrees = adjacentDegrees;
    }

    static Network oldNetwork;

    public static void generateOldNetwork(){
        oldNetwork = new Network();
        for (int i = 0; i < oldGraph.length; i++){
            oldNetwork.nodes.add(oldGraph[i]);
        }
        updateNetworkNodeDegrees(oldNetwork);
    }

    public static void updateCost(Network network) {
        Set<Integer> visited = new HashSet<>();
        for (Node n : network.nodes) {
            visited.add(n.id);
            for (Node adj : newGraphEdges.get(n.id)) {
                if (network.nodes.contains(adj) && !visited.contains(adj.id)) {
                    network.totalCost += adj.cost;
                }
            }
        }
    }

    public static Network updateMax() {
        Network minCostNetwork = null;
        int minCost = Integer.MAX_VALUE;
        for(Network n : generator.possibleNetworks){
            if (n.fast_servers == generator.max_fast_servers){
                updateCost(n);
                if (minCost > n.totalCost) {
                    minCost = n.totalCost;
                    minCostNetwork = n;
                }
//                System.out.println(Arrays.toString(n.nodes.toArray()) + " -->" + n.totalCost);
            }
        }
//        System.out.println(Arrays.toString(minCostNetwork.nodes.toArray()) + " -->" + minCostNetwork.totalCost);
        return minCostNetwork;
    }

    public static void main(String[] args) throws IOException {
        read();

        int[] set = new int[new_n_servers];
        for (int i = 0; i < new_n_servers; i++) {
            set[i] = i;
        }

        generateOldNetwork();

        generator = new NetworkGenerator(newGraphEdges, set, newGraph, old_n_connections, old_n_servers, oldNetwork);
        generator.k_subsets(old_n_servers, 0, new int[old_n_servers],0);
        //runPackCombinations();

        Network minCostNet = updateMax();

        System.out.println(generator.max_fast_servers + " " + minCostNet.totalCost);
    }
}
